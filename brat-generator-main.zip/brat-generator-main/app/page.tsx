"use client"

import { useState, useRef } from "react"
import html2canvas from "html2canvas"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Download, RotateCcw } from "lucide-react"

interface BratSettings {
  text: string
  textColor: string
  backgroundColor: string
  fontSize: number
  blur: number
  width: number
  height: number
  borderRadius: number
}

const defaultSettings: BratSettings = {
  text: "",
  textColor: "#000000",
  backgroundColor: "#C6FF00",
  fontSize: 120,
  blur: 0,
  width: 600,
  height: 400,
  borderRadius: 0,
}

export default function BratGenerator() {
  const [settings, setSettings] = useState<BratSettings>(defaultSettings)
  const previewRef = useRef<HTMLDivElement>(null)

  const updateSetting = (key: keyof BratSettings, value: string | number) => {
    setSettings((prev) => ({ ...prev, [key]: value }))
  }

  const resetSettings = () => {
    setSettings(defaultSettings)
  }

  const downloadImage = async () => {
    if (!previewRef.current) return

    try {
      const canvas = await html2canvas(previewRef.current, {
        backgroundColor: null,
        scale: 2,
        useCORS: true,
      })

      const link = document.createElement("a")
      link.download = `brat-${settings.text.toLowerCase().replace(/\s+/g, "-") || "text"}.png`
      link.href = canvas.toDataURL()
      link.click()
    } catch (error) {
      console.error("Error generating image:", error)
    }
  }

  return (
    <div className="min-h-screen bg-[#0B0B0B] text-white">
      {/* Header */}
      <header className="border-b border-gray-800 py-3 sm:py-4 md:py-6">
        <div className="container mx-auto px-3 sm:px-4">
          <h1 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-center">
            <span className="text-[#C6FF00]">brat</span> generator
          </h1>
          <p className="text-gray-400 text-center mt-1 sm:mt-2 text-xs sm:text-sm md:text-base">
            create viral stylized text graphics • no login required
          </p>
        </div>
      </header>

      {/* Main Generator */}
      <main className="container mx-auto px-3 sm:px-4 py-3 sm:py-4 md:py-6 lg:py-8 max-w-7xl">
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-3 sm:gap-4 md:gap-6 lg:gap-8">
          {/* Left Column - Controls */}
          <div className="space-y-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-[#C6FF00]">Controls</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 sm:space-y-4 md:space-y-6 p-3 sm:p-4 md:p-6">
                {/* Text Input */}
                <div className="space-y-2">
                  <Label htmlFor="text" className="text-white font-medium mb-1">
                    Text
                  </Label>
                  <Input
                    id="text"
                    placeholder="Enter your brat text..."
                    value={settings.text}
                    onChange={(e) => updateSetting("text", e.target.value)}
                    className="bg-[#1E1E1E] text-white placeholder:text-gray-400 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-lime-400 border-0"
                  />
                </div>

                {/* Color Pickers */}
                <div className="grid grid-cols-1 xs:grid-cols-2 gap-3 sm:gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="textColor" className="text-white font-medium mb-1 text-sm">
                      Text Color
                    </Label>
                    <div className="flex items-center space-x-2">
                      <input
                        id="textColor"
                        type="color"
                        value={settings.textColor}
                        onChange={(e) => updateSetting("textColor", e.target.value)}
                        className="w-10 h-10 sm:w-12 sm:h-10 rounded border border-gray-700 bg-gray-800 cursor-pointer flex-shrink-0"
                      />
                      <Input
                        value={settings.textColor}
                        onChange={(e) => updateSetting("textColor", e.target.value)}
                        className="bg-[#1E1E1E] text-white placeholder:text-gray-400 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-lime-400 border-0 text-xs sm:text-sm flex-1 min-w-0"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="backgroundColor" className="text-white font-medium mb-1 text-sm">
                      Background Color
                    </Label>
                    <div className="flex items-center space-x-2">
                      <input
                        id="backgroundColor"
                        type="color"
                        value={settings.backgroundColor}
                        onChange={(e) => updateSetting("backgroundColor", e.target.value)}
                        className="w-10 h-10 sm:w-12 sm:h-10 rounded border border-gray-700 bg-gray-800 cursor-pointer flex-shrink-0"
                      />
                      <Input
                        value={settings.backgroundColor}
                        onChange={(e) => updateSetting("backgroundColor", e.target.value)}
                        className="bg-[#1E1E1E] text-white placeholder:text-gray-400 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-lime-400 border-0 text-xs sm:text-sm flex-1 min-w-0"
                      />
                    </div>
                  </div>
                </div>

                {/* Sliders */}
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-white font-medium mb-1 text-sm">
                      Font Size: <span className="text-[#C6FF00]">{settings.fontSize}px</span>
                    </Label>
                    <Slider
                      value={[settings.fontSize]}
                      onValueChange={(value) => updateSetting("fontSize", value[0])}
                      min={30}
                      max={200}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-white font-medium mb-1 text-sm">
                      Blur: <span className="text-[#C6FF00]">{settings.blur}px</span>
                    </Label>
                    <Slider
                      value={[settings.blur]}
                      onValueChange={(value) => updateSetting("blur", value[0])}
                      min={0}
                      max={20}
                      step={0.5}
                      className="w-full"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-white font-medium mb-1 text-sm">
                      Width: <span className="text-[#C6FF00]">{settings.width}px</span>
                    </Label>
                    <Slider
                      value={[settings.width]}
                      onValueChange={(value) => updateSetting("width", value[0])}
                      min={300}
                      max={1000}
                      step={10}
                      className="w-full"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-white font-medium mb-1 text-sm">
                      Height: <span className="text-[#C6FF00]">{settings.height}px</span>
                    </Label>
                    <Slider
                      value={[settings.height]}
                      onValueChange={(value) => updateSetting("height", value[0])}
                      min={200}
                      max={1000}
                      step={10}
                      className="w-full"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-white font-medium mb-1 text-sm">
                      Border Radius: <span className="text-[#C6FF00]">{settings.borderRadius}px</span>
                    </Label>
                    <Slider
                      value={[settings.borderRadius]}
                      onValueChange={(value) => updateSetting("borderRadius", value[0])}
                      min={0}
                      max={500}
                      step={5}
                      className="w-full"
                    />
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col xs:flex-row gap-2 sm:gap-3 pt-3 sm:pt-4">
                  <Button
                    onClick={resetSettings}
                    variant="outline"
                    className="flex-1 border-gray-700 text-white hover:bg-gray-800 bg-transparent h-10 sm:h-11 text-sm font-medium"
                  >
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Reset
                  </Button>
                  <Button
                    onClick={downloadImage}
                    className="flex-1 bg-[#C6FF00] text-black hover:bg-[#B8E600] font-bold h-10 sm:h-11 text-sm transition-all duration-200 hover:scale-105"
                    disabled={!settings.text.trim()}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Preview */}
          <div className="space-y-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-[#C6FF00]">Live Preview</CardTitle>
              </CardHeader>
              <CardContent className="p-3 sm:p-4 md:p-6">
                <div className="flex justify-center overflow-hidden">
                  <div
                    ref={previewRef}
                    style={{
                      width: `${Math.min(settings.width, typeof window !== "undefined" ? window.innerWidth - 60 : settings.width)}px`,
                      height: `${settings.height}px`,
                      backgroundColor: settings.backgroundColor,
                      borderRadius: `${settings.borderRadius}px`,
                      filter: `blur(${settings.blur}px)`,
                    }}
                    className="flex items-center justify-center transition-all duration-300 ease-in-out max-w-full shadow-lg"
                  >
                    <span
                      style={{
                        fontSize: `${Math.min(settings.fontSize, (typeof window !== "undefined" ? Math.min(settings.width, window.innerWidth - 60) : settings.width) / 4)}px`,
                        color: settings.textColor,
                      }}
                      className="font-bold lowercase text-center px-2 sm:px-4 leading-tight break-words"
                    >
                      {settings.text || "enter text"}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* How to Use Section */}
        <section className="mt-6 sm:mt-8 md:mt-12 lg:mt-16">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-2xl text-[#C6FF00]">How to Use Brat Generator</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 md:gap-6">
                <div className="space-y-2">
                  <h3 className="font-bold text-[#C6FF00]">Step 1 – Enter Your Text</h3>
                  <p className="text-gray-300">Type the word or phrase you want to style.</p>
                </div>
                <div className="space-y-2">
                  <h3 className="font-bold text-[#C6FF00]">Step 2 – Customize the Look</h3>
                  <p className="text-gray-300">
                    Pick your text and background colors. Adjust font size, width, height, blur, and corner radius.
                  </p>
                </div>
                <div className="space-y-2">
                  <h3 className="font-bold text-[#C6FF00]">Step 3 – See Live Preview</h3>
                  <p className="text-gray-300">Watch your design change instantly on the right side.</p>
                </div>
                <div className="space-y-2">
                  <h3 className="font-bold text-[#C6FF00]">Step 4 – Download</h3>
                  <p className="text-gray-300">Click "Download" to save your styled image as PNG.</p>
                </div>
                <div className="space-y-2">
                  <h3 className="font-bold text-[#C6FF00]">Step 5 – Reset (Optional)</h3>
                  <p className="text-gray-300">Use "Reset" to go back to defaults and start fresh.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* FAQ Section */}
        <section className="mt-6 sm:mt-8 md:mt-12 lg:mt-16">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-2xl text-[#C6FF00]">Frequently Asked Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="format" className="border-gray-700">
                  <AccordionTrigger className="text-white hover:text-[#C6FF00]">
                    What format are the images?
                  </AccordionTrigger>
                  <AccordionContent className="text-gray-300">
                    PNG format, high-quality, suitable for web or print.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="limit" className="border-gray-700">
                  <AccordionTrigger className="text-white hover:text-[#C6FF00]">
                    Is there a limit on how many I can create?
                  </AccordionTrigger>
                  <AccordionContent className="text-gray-300">
                    No limit. Create and download as many as you want.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="commercial" className="border-gray-700">
                  <AccordionTrigger className="text-white hover:text-[#C6FF00]">
                    Can I use these images commercially?
                  </AccordionTrigger>
                  <AccordionContent className="text-gray-300">
                    Yes. You're free to use them for any personal or commercial project.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="login" className="border-gray-700">
                  <AccordionTrigger className="text-white hover:text-[#C6FF00]">Do I need to log in?</AccordionTrigger>
                  <AccordionContent className="text-gray-300">
                    Nope. No sign-up required — just start creating.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="fonts" className="border-gray-700">
                  <AccordionTrigger className="text-white hover:text-[#C6FF00]">
                    Can I use different fonts?
                  </AccordionTrigger>
                  <AccordionContent className="text-gray-300">
                    Not yet — we currently use a bold default font, but font switching is coming soon.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-800 mt-6 sm:mt-8 md:mt-12 lg:mt-16 py-4 sm:py-6 md:py-8">
        <div className="container mx-auto px-3 sm:px-4">
          <div className="flex flex-col sm:flex-row justify-between items-center space-y-2 sm:space-y-0 text-center sm:text-left">
            <p className="text-gray-400 text-xs sm:text-sm order-2 sm:order-1">
              © 2025 Brat Generator. All rights reserved.
            </p>
            <div className="flex space-x-3 sm:space-x-4 md:space-x-6 order-1 sm:order-2">
              <a
                href="#"
                className="text-gray-400 hover:text-[#C6FF00] text-xs sm:text-sm transition-colors duration-200"
              >
                Privacy Policy
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-[#C6FF00] text-xs sm:text-sm transition-colors duration-200"
              >
                Terms of Service
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
