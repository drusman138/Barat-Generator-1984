"use client"

import type React from "react"

import { memo } from "react"

interface OptimizedPreviewProps {
  text: string
  textColor: string
  backgroundColor: string
  fontSize: number
  blur: number
  width: number
  height: number
  borderRadius: number
  previewRef: React.RefObject<HTMLDivElement>
}

const OptimizedPreview = memo(function OptimizedPreview({
  text,
  textColor,
  backgroundColor,
  fontSize,
  blur,
  width,
  height,
  borderRadius,
  previewRef,
}: OptimizedPreviewProps) {
  const responsiveWidth = typeof window !== "undefined" ? Math.min(width, window.innerWidth - 40) : width
  const responsiveFontSize = Math.min(fontSize, responsiveWidth / 4)

  return (
    <div className="flex justify-center overflow-hidden">
      <div
        ref={previewRef}
        style={{
          width: `${responsiveWidth}px`,
          height: `${height}px`,
          backgroundColor,
          borderRadius: `${borderRadius}px`,
          filter: `blur(${blur}px)`,
        }}
        className="flex items-center justify-center transition-all duration-300 ease-in-out max-w-full shadow-lg"
      >
        <span
          style={{
            fontSize: `${responsiveFontSize}px`,
            color: textColor,
          }}
          className="font-bold lowercase text-center px-4 leading-tight break-words"
        >
          {text || "enter text"}
        </span>
      </div>
    </div>
  )
})

export default OptimizedPreview
